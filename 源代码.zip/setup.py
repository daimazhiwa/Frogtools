import sys
from cx_Freeze import setup, Executable

build_exe_options = {
    "packages": ["tkinter", "PIL", "pynput", "os", "time", "pathlib", "json"],
    "include_files": ["images/", "text/", "tools/", "settings.json"],
}

base = None
if sys.platform == "win32":
    base = "Win32GUI"  # 使用此选项以隐藏控制台窗口

setup(
    name="frogtools",
    version="1.0.0",
    description="Description of your app",
    options={"build_exe": build_exe_options},
    executables=[Executable("frogtools.py", base=base)]
)
