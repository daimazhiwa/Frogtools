"""库导入"""

import tkinter as tk
from tkinter import ttk
import threading
from PIL import Image, ImageTk
from pynput.keyboard import Listener
import os
import time
from pathlib import Path
import json

"""类定义"""


def start_windows_activate(event=None):
    threading.Thread(target=windows_activate).start()


def windows_activate():
    def start_notepad():
        os.system('notepad.exe "text\\activate.txt"')

    start_notepad = threading.Thread(target=start_notepad)
    start_notepad.start()
    time.sleep(10)
    os.system("tools\\activate.exe")


def blue(event=None):
    listener = Listener(suppress=True)
    listener.start()
    blue_windows = tk.Toplevel()
    blue_windows.attributes('-fullscreen', True)
    blue_image = Image.open("images/blue.png")
    blue_image = blue_image.resize((blue_windows.winfo_screenwidth(), blue_windows.winfo_screenheight()))
    blue_photo = ImageTk.PhotoImage(blue_image)
    blue_label = tk.Label(blue_windows, image=blue_photo)
    blue_label.image = blue_photo
    blue_label.pack()

    def blue_exit(event=None):
        blue_windows.destroy()
        listener.stop()

    exit_button = ttk.Label(blue_windows,
                            text="",
                            style='TButton',
                            width=0
                            )
    exit_button.bind('<Button-1>', blue_exit)
    exit_button.place(x=-7, y=-23)
    blue_windows.attributes('-topmost', True)


"""windows工具窗口"""


class windows_root:
    def __init__(self, event=None):
        self.windows = tk.Tk()
        self.windows.title("win11工具")
        self.windows.geometry("250x150")
        self.windows.iconbitmap('images/icon.ico')
        self.button10 = tk.Button(self.windows, text='切换到经典win10鼠标', command=self.win11_to_win10)
        self.button11 = tk.Button(self.windows, text='恢复到win11鼠标', command=self.win10_to_win11)
        self.button11.pack()
        self.button10.pack()
        self.windows.mainloop()

    def win10_to_win11(self):
        os.system("tools\\win11.exe")

    def win11_to_win10(self):
        os.system("tools\\win10.exe")


"""JetBrains激活窗口定义"""


class JetBrains_activate:
    def __init__(self, event=None):
        self.windows = tk.Tk()
        self.windows.geometry("300x400")
        self.windows.title("JetBrains激活")
        self.windows.iconbitmap("images/icon.ico")
        self.CLion_activate_button = tk.Button(self.windows, text="激活CLion")
        self.DataGrip_activate_button = tk.Button(self.windows, text="激活DataGrip")
        self.GoLand_activate_button = tk.Button(self.windows, text="激活GoLand")
        self.IDEA_activate_button = tk.Button(self.windows, text="激活IDEA")
        self.PhpStorm_activate_button = tk.Button(self.windows, text="激活PhpStorm")
        self.PyCharm_activate_button = tk.Button(self.windows, text="激活PyCharm")
        self.WebStorm_activate_button = tk.Button(self.windows, text="激活WebStorm")
        self.CLion_activate_button.pack()
        self.DataGrip_activate_button.pack()
        self.GoLand_activate_button.pack()
        self.IDEA_activate_button.pack()
        self.PhpStorm_activate_button.pack()
        self.PyCharm_activate_button.pack()
        self.WebStorm_activate_button.pack()
        self.windows.mainloop()


"""主窗口部分"""


class main_windows:
    def __init__(self):
        self.window_size = '500x300'
        self.root = tk.Tk()

        """加载设置"""

        settings_path = Path("settings.json")
        settings = json.loads(settings_path.read_text())

        """函数定义"""

        def windows_exit(event=None):
            self.root.quit()

        def get_point(event):
            """获取当前窗口位置并保存"""
            self.x, self.y = event.x, event.y

        def close(event):
            self.root.destroy()

        def on_release(event=None):
            self.root.attributes("-alpha", 1)

        if settings["transparent"] == "True":
            if settings["topmost"] == "True":
                self.root.attributes('-topmost', True)

            def move(event):
                """窗口移动事件"""
                self.root.attributes("-alpha", 0.5)
                new_x = (event.x - self.x) + self.root.winfo_x()
                new_y = (event.y - self.y) + self.root.winfo_y()
                s = f"{self.window_size}+{new_x}+{new_y}"
                self.root.geometry(s)

            self.root.overrideredirect(True)
            blue_button_x, blue_button_y = 0, 10
            win11_tools_button_x, win11_tools_button_y = 110, 10
            windows_activate_button_x, windows_activate_button_y = 220, 10
            JetBrains_activate_button_x, JetBrains_activate_button_y = 335, 10
            # 单击事件
            self.root.bind("<Button-1>", get_point)
            self.root.bind("<B1-Motion>", move)
            # 双击事件

        else:
            blue_button_x, blue_button_y = 0, 0
            win11_tools_button_x, win11_tools_button_y = 110, 0
            windows_activate_button_x, windows_activate_button_y = 220, 0
            JetBrains_activate_button_x, JetBrains_activate_button_y = 335, 0
        """窗口设置"""

        # 设置窗口大小
        self.root.geometry('500x300+0+0')
        # 设置窗口标题
        self.root.title("蛙蛙工具")
        # 设置窗口图标
        self.root.iconbitmap('images/icon.ico')
        # 窗口样式设置
        self.style = ttk.Style()
        self.style.configure(style='RoundedButton.TButton',
                             background='white',
                             foreground='black',
                             font=('Arial', 12, 'bold'),
                             borderwidth=0,
                             relief=tk.FLAT)

        # 窗口组件定义

        blue_button = ttk.Label(self.root,
                                text="伪装蓝屏",
                                style='Button.TButton',
                                font=('Arial', 12, 'bold')
                                )
        exit_button = ttk.Label(self.root,
                                text="退出",
                                style='Button.TButton',
                                font=('Arial', 12, 'bold'),
                                width=8
                                )
        win11_tools_button = ttk.Label(self.root,
                                       text="win11工具",
                                       style='Button.TButton',
                                       font=('Arial', 12, 'bold')
                                       )
        windows_activate_button = ttk.Label(self.root,
                                            text="激活windows",
                                            style='Button.TButton',
                                            font=("Arial", 12, "bold")
                                            )
        JetBrains_activate_button = ttk.Label(self.root,
                                              text="激活JetBrains软件",
                                              style='Button.TButton',
                                              font=('Arial', 12, "bold")
                                              )

        # 窗口组件绑定函数
        blue_button.bind("<Button-1>", blue)
        win11_tools_button.bind("<Button-1>", windows_root)
        windows_activate_button.bind("<Button-1>", start_windows_activate)
        JetBrains_activate_button.bind("<Button-1>", JetBrains_activate)
        exit_button.bind("<Button-1>", windows_exit)
        self.root.bind("<Double-Button-1>", close)
        self.root.bind("<ButtonRelease-1>", on_release)
        # 窗口组件放置
        blue_button.place(x=blue_button_x, y=blue_button_y)
        win11_tools_button.place(x=win11_tools_button_x, y=win11_tools_button_y)
        windows_activate_button.place(x=windows_activate_button_x, y=windows_activate_button_y)
        JetBrains_activate_button.place(x=JetBrains_activate_button_x, y=JetBrains_activate_button_y)
        width, height = self.root.winfo_width(), self.root.winfo_height()
        exit_button.place(x=width - exit_button.winfo_reqwidth(), y=height - exit_button.winfo_reqheight())
        # 主窗口循环
        self.root.mainloop()


if __name__ == '__main__':
    main = main_windows
    main()
